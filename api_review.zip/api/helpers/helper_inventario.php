<?php

function obtener_query_pedidos_pendientes(){

}
?>