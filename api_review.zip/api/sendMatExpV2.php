<?php
require('../conect.php');
require_once(__DIR__ . "/../logger/logger.php");
require_once(__DIR__ . "/../utils/guardar_registros.php");
header('Content-type: application/json; charset=utf-8');


